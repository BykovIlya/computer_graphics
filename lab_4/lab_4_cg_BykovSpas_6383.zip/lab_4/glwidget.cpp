#include "glwidget.h"

GLWidget::GLWidget()
{

}
